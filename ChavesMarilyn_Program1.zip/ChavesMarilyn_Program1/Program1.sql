--/***************************************************************/
--  Developer:            Marilyn Chaves Chaves
--
--  Program #:            ONE
--
--  File Name:            Program1.sql
--
--  Course:               ITSE 1345 Introduction to Oracle SQL and PL/SQL
--
--  Due Date:             February 4th, 2022
--
--  Instructor:           Fred Kumi 
--
--  Chapter:              TWO
--
--  Description:
--      
--     This programs creates a PL/SQL anonymous block that displays today's date and the statement 
--     'This is my first PL/SQL Block', by declaring a variable to store the date and use the 
--     DBMS_OUTPUT.PUT_LINE procedure to display it on the screen.
--
--/**********************************************************************************************/
SET serveroutput ON;

DECLARE
	lv_date DATE; 
   
BEGIN
	DBMS_OUTPUT.PUT_LINE(chr(30));
	DBMS_OUTPUT.PUT_LINE('This is my first PL/SQL Block');
	lv_date := SYSDATE;
	DBMS_OUTPUT.PUT_LINE(chr(13));
	DBMS_OUTPUT.PUT_LINE('Today''s date is: ' || lv_date);
	   
END;
/